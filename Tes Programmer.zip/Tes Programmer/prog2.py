import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from datetime import datetime
import requests
import json
import sqlite3

class KaryawanApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Aplikasi Manajemen Karyawan")

        self.conn = sqlite3.connect('karyawan.db')
        self.create_table()

        self.create_form_i()

        self.create_form_ii()

    def create_table(self):
        cursor = self.conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS karyawan (
                IDKaryawan TEXT PRIMARY KEY,
                NmKaryawan TEXT,
                TglMasukKerja DATETIME,
                Usia INTEGER
            )
        ''')
        self.conn.commit()

    def create_form_i(self):
        filter_label = ttk.Label(self.root, text="Filter Data:")
        filter_label.grid(row=0, column=0, padx=10, pady=10, sticky="w")

        self.nama_var = tk.StringVar()
        self.nama_entry = ttk.Entry(self.root, textvariable=self.nama_var)
        self.nama_entry.grid(row=0, column=1, padx=10, pady=10)

        ttk.Label(self.root, text="s/d").grid(row=0, column=2, padx=10, pady=10)

        self.sampai_nama_var = tk.StringVar()
        self.sampai_nama_entry = ttk.Entry(self.root, textvariable=self.sampai_nama_var)
        self.sampai_nama_entry.grid(row=0, column=3, padx=10, pady=10)

        ttk.Label(self.root, text="Usia").grid(row=1, column=0, padx=10, pady=10)

        self.usia_var = tk.IntVar()
        self.usia_entry = ttk.Entry(self.root, textvariable=self.usia_var)
        self.usia_entry.grid(row=1, column=1, padx=10, pady=10)

        ttk.Label(self.root, text="s/d").grid(row=1, column=2, padx=10, pady=10)

        self.sampai_usia_var = tk.IntVar()
        self.sampai_usia_entry = ttk.Entry(self.root, textvariable=self.sampai_usia_var)
        self.sampai_usia_entry.grid(row=1, column=3, padx=10, pady=10)

        ttk.Label(self.root, text="Tgl Masuk Kerja").grid(row=2, column=0, padx=10, pady=10)

        self.tgl_masuk_var = tk.StringVar()
        self.tgl_masuk_entry = ttk.Entry(self.root, textvariable=self.tgl_masuk_var)
        self.tgl_masuk_entry.grid(row=2, column=1, padx=10, pady=10)

        ttk.Label(self.root, text="s/d").grid(row=2, column=2, padx=10, pady=10)

        self.sampai_tgl_masuk_var = tk.StringVar()
        self.sampai_tgl_masuk_entry = ttk.Entry(self.root, textvariable=self.sampai_tgl_masuk_var)
        self.sampai_tgl_masuk_entry.grid(row=2, column=3, padx=10, pady=10)

        search_button = ttk.Button(self.root, text="Search", command=self.search_data)
        search_button.grid(row=3, column=0, columnspan=4, pady=10)

        self.tree = ttk.Treeview(self.root, columns=("ID", "Nama", "Tgl Masuk Kerja", "Usia"), show="headings")
        self.tree.heading("ID", text="ID")
        self.tree.heading("Nama", text="Nama")
        self.tree.heading("Tgl Masuk Kerja", text="Tgl Masuk Kerja")
        self.tree.heading("Usia", text="Usia")
        self.tree.grid(row=4, column=0, columnspan=4, padx=10, pady=10)

        new_button = ttk.Button(self.root, text="New", command=self.show_form_ii)
        new_button.grid(row=5, column=0, pady=10)

        edit_button = ttk.Button(self.root, text="Edit", command=self.edit_data)
        edit_button.grid(row=5, column=1, pady=10)

        delete_button = ttk.Button(self.root, text="Delete", command=self.delete_data)
        delete_button.grid(row=5, column=2, pady=10)

        close_button = ttk.Button(self.root, text="Close", command=self.root.destroy)
        close_button.grid(row=5, column=3, pady=10)

    def create_form_ii(self):
        self.form_ii = tk.Toplevel(self.root)
        self.form_ii.title("Form Entry Data")

        ttk.Label(self.form_ii, text="ID").grid(row=0, column=0, padx=10, pady=10)
        self.id_var = tk.StringVar()
        ttk.Entry(self.form_ii, textvariable=self.id_var, state="readonly").grid(row=0, column=1, padx=10, pady=10)

        ttk.Label(self.form_ii, text="Nama").grid(row=1, column=0, padx=10, pady=10)
        self.nama_form_var = tk.StringVar()
        ttk.Entry(self.form_ii, textvariable=self.nama_form_var).grid(row=1, column=1, padx=10, pady=10)

        ttk.Label(self.form_ii, text="Usia").grid(row=2, column=0, padx=10, pady=10)
        self.usia_form_var = tk.IntVar()
        ttk.Entry(self.form_ii, textvariable=self.usia_form_var).grid(row=2, column=1, padx=10, pady=10)

        ttk.Label(self.form_ii, text="Tgl Masuk Kerja").grid(row=3, column=0, padx=10, pady=10)
        self.tgl_masuk_form_var = tk.StringVar()
        ttk.Entry(self.form_ii, textvariable=self.tgl_masuk_form_var).grid(row=3, column=1, padx=10, pady=10)

        save_button = ttk.Button(self.form_ii, text="Save", command=self.save_data)
        save_button.grid(row=4, column=0, columnspan=2, pady=10)

    def search_data(self):
        nama = self.nama_var.get()
        sampai_nama = self.sampai_nama_var.get()
        usia = self.usia_var.get()
        sampai_usia = self.sampai_usia_var.get()
        tgl_masuk = self.tgl_masuk_var.get()
        sampai_tgl_masuk = self.sampai_tgl_masuk_var.get()

        query = "SELECT * FROM karyawan WHERE 1=1"
        params = []

        if nama:
            query += " AND NmKaryawan LIKE ?"
            params.append(f'%{nama}%')

        if sampai_nama:
            query += " AND NmKaryawan <= ?"
            params.append(sampai_nama)

        if usia is not None:
            query += " AND Usia BETWEEN ? AND ?"
            params.append(usia)
            params.append(sampai_usia)

        if tgl_masuk:
            query += " AND TglMasukKerja >= ?"
            params.append(tgl_masuk)

        if sampai_tgl_masuk:
            query += " AND TglMasukKerja <= ?"
            params.append(sampai_tgl_masuk)

        cursor = self.conn.cursor()
        cursor.execute(query, params)
        data = cursor.fetchall()

        self.tree.delete(*self.tree.get_children())

        for row in data:
            self.tree.insert("", "end", values=row)

    def show_form_ii(self):
        self.id_var.set("")
        self.nama_form_var.set("")
        self.usia_form_var.set("")
        self.tgl_masuk_form_var.set("")

        self.form_ii.deiconify()

    def edit_data(self):
        selected_item = self.tree.selection()
        if not selected_item:
            messagebox.showinfo("Info", "Pilih data yang akan diedit.")
            return

        id_karyawan = self.tree.item(selected_item)['values'][0]
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM karyawan WHERE IDKaryawan=?", (id_karyawan,))
        data = cursor.fetchone()

        self.id_var.set(data[0])
        self.nama_form_var.set(data[1])
        self.usia_form_var.set(data[3])
        self.tgl_masuk_form_var.set(data[2])

        self.form_ii.deiconify()

    def delete_data(self):
        selected_item = self.tree.selection()
        if not selected_item:
            messagebox.showinfo("Info", "Pilih data yang akan dihapus.")
            return

        id_karyawan = self.tree.item(selected_item)['values'][0]

        confirm = messagebox.askyesno("Konfirmasi", "Anda yakin ingin menghapus data ini?")
        if confirm:
            cursor = self.conn.cursor()
            cursor.execute("DELETE FROM karyawan WHERE IDKaryawan=?", (id_karyawan,))
            self.conn.commit()

            self.tree.delete(selected_item)

    def save_data(self):
        id_karyawan = self.id_var.get()
        nama = self.nama_form_var.get()
        usia = self.usia_form_var.get()
        tgl_masuk = self.tgl_masuk_form_var.get()

        if not nama or not usia or not tgl_masuk:
            messagebox.showerror("Error", "Semua data harus diisi.")
            return

        try:
            tgl_masuk = datetime.strptime(tgl_masuk, "%Y-%m-%d")
        except ValueError:
            messagebox.showerror("Error", "Format Tgl Masuk Kerja salah. Gunakan format YYYY-MM-DD.")
            return

        cursor = self.conn.cursor()
        if id_karyawan:
            cursor.execute("UPDATE karyawan SET NmKaryawan=?, Usia=?, TglMasukKerja=? WHERE IDKaryawan=?",
                           (nama, usia, tgl_masuk, id_karyawan))
        else:
            cursor.execute("INSERT INTO karyawan (NmKaryawan, Usia, TglMasukKerja) VALUES (?, ?, ?)",
                           (nama, usia, tgl_masuk))

        self.conn.commit()

        self.form_ii.withdraw()

        self.search_data()


if __name__ == "__main__":
    root = tk.Tk()
    app = KaryawanApp(root)
    root.mainloop()

    def show_github_data(self):
    url = "https://api.github.com/users/google/repos"
    response = requests.get(url)

    if response.status_code == 200:
        data = json.loads(response.text)
        self.tree.delete(*self.tree.get_children())

        for repo in data:
            self.tree.insert("", "end", values=(repo['id'], repo['name'], repo['html_url']))
    else:
        messagebox.showerror("Error", "Gagal mengambil data dari GitHub API.")

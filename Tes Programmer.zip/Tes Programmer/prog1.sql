-- Membuat database SQLite
CREATE TABLE Karyawan (
    IDKaryawan TEXT PRIMARY KEY,
    NmKaryawan TEXT,
    TglMasukKerja DATETIME,
    Usia INTEGER
);

-- Memasukkan data ke dalam tabel
INSERT INTO Karyawan (IDKaryawan, NmKaryawan, TglMasukKerja, Usia) VALUES
    ('001', 'Andi', '2012-03-02', 25),
    ('002', 'Anto', '2013-06-02', 24),
    ('003', 'Adi', '2000-05-21', 27),
    ('004', 'Amin', '2018-08-05', 31);